# MOVING GT - placeholder KivyMD app
# NOTE: This file is a minimal skeleton so GitHub Actions can build the APK.
# Replace this file with the full app code (provided in README.txt) if needed.

from kivy.utils import platform
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.uix.label import MDLabel

KV = '''
MDScreen:
    MDBoxLayout:
        MDLabel:
            text: "MOVING GT (Placeholder)\nReplace main.py with full app from README.txt"
            halign: "center"
'''

class TransporteApp(MDApp):
    def build(self):
        self.theme_cls.primary_palette = "Blue"
        self.theme_cls.theme_style = "Light"
        return Builder.load_string(KV)

if __name__ == '__main__':
    TransporteApp().run()
