MOVING GT - Android project (offline + synchronizable)

Included files:
- main.py                : Placeholder KivyMD app (replace with full code below)
- buildozer.spec
- icon.png
- .github/workflows/build.yml
- README.txt             : this file (contains instructions and full app code snippet)

How to build via GitHub Actions:
1) Create a new GitHub repository and push all files from this folder to the repo (main branch).
2) GitHub Actions will run and build the APK automatically. Download the artifact from Actions -> run -> Artifacts.
   Note: first build downloads Android SDK/NDK and may take a long time.
3) To use full features (camera, sync), replace main.py with the full app code included at the end of this README.

Server endpoint for sync (POST multipart/form-data):
- Fields: fecha, cliente, telefono, direccion_origen, direccion_destino, precio_final, nota
- Files: foto_lado1, foto_lado2
Return HTTP 200 on success.

--- Full app code (replace main.py with this for full functionality) ---
(Full MOVING GT app code - copy this into main.py to get full features)
[...Paste the full code provided earlier here...]

